# wizard/__init__.py
from . import tour_selection_wizard
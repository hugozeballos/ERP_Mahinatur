from odoo import models, fields, api
from odoo.exceptions import ValidationError

class TourMinimal(models.Model):
    _name = 'tour.minimal'
    _description = 'Tour Minimal'

    name = fields.Char(string='Nombre del Tour', required=True)
    date_start = fields.Datetime(string='Fecha/Hora de Inicio', required=True)
    date_end = fields.Datetime(string='Fecha/Hora de Fin')
    max_capacity = fields.Integer(string='Capacidad Máxima', default=10)
    participants_ids = fields.One2many('tour.participant', 'tour_id', string='Participantes')
    guide_id = fields.Many2one('hr.employee', string='Guía', ondelete='set null')
    guide_cost = fields.Float(string='Costo del Guía')
    driver_id = fields.Many2one('hr.employee', string='Chofer', ondelete='set null')
    driver_cost = fields.Float(string='Costo del Chofer')
    vehicle_id = fields.Many2one('fleet.vehicle', string='Vehículo', ondelete='set null')
    vehicle_cost = fields.Float(string='Costo del Vehículo')
    total_cost = fields.Float(string='Costo Total', compute='_compute_total_cost', store=True)
    available_seats = fields.Integer(string='Cupos Disponibles', compute='_compute_available_seats', store=True)
    sale_order_ids = fields.One2many('sale.order', 'tour_id', string='Ventas Asociadas')


    @api.depends('guide_cost', 'driver_cost', 'vehicle_cost')
    def _compute_total_cost(self):
        for tour in self:
            tour.total_cost = (tour.guide_cost or 0.0) + (tour.driver_cost or 0.0) + (tour.vehicle_cost or 0.0)

    @api.depends('max_capacity', 'participants_ids')
    def _compute_available_seats(self):
        for tour in self:
            tour.available_seats = tour.max_capacity - len(tour.participants_ids)

    @api.constrains('participants_ids', 'max_capacity')
    def _check_capacity(self):
        for tour in self:
            if len(tour.participants_ids) > tour.max_capacity:
                raise ValidationError("El número de participantes excede la capacidad máxima.")
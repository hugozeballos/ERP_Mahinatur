{
    "name": "Tour Minimal Odoo 17",
    "version": "1.0",
    "summary": "Módulo mínimo para Odoo 17",
    "author": "ChatGPT",
    "depends": ["base", "hr", "fleet", 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/tour_minimal_views.xml',
        'views/tour_participant_views.xml',
        'views/sale_order_inherit_views.xml',
        'views/wizard/tour_selection_wizard_views.xml',
        'views/sale_order_form_inherit_tour.xml',  # <--- agrega aquí tu nueva vista
    ],
    "images": ['static/description/icon.png'],
    "installable": True,
    "application": True,
    "license": "LGPL-3"
}
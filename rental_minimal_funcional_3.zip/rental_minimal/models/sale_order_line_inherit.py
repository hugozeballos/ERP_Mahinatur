# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    rental_start_date = fields.Datetime(string="Fecha inicio arriendo")
    rental_end_date = fields.Datetime(string="Fecha fin arriendo")

    @api.constrains('rental_start_date', 'rental_end_date', 'product_uom_qty')
    def _check_rental_dates_and_qty(self):
        for line in self:
            if line.product_id and line.product_id.is_vehicle_rental:
                if not line.rental_start_date or not line.rental_end_date:
                    raise ValidationError("Debe especificar fechas de inicio y fin para vehículos en arriendo.")
                rental_days = (line.rental_end_date - line.rental_start_date).days
                if rental_days <= 0:
                    raise ValidationError("La fecha de fin debe ser posterior a la fecha de inicio.")
                if rental_days != line.product_uom_qty:
                    raise ValidationError(f"La cantidad debe ser igual a los días de arriendo ({rental_days} días).")

from . import fleet_vehicle_extend
from . import rental_booking
from . import rental_return_wizard
from . import sale_order_inherit
from . import sale_order_line_inherit
from . import product_template_extend

